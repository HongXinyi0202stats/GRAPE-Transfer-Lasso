from matplotlib import pyplot as plt
import numpy as np
def draw():
    # Define the coordinates for the heatmap
    xLabel = ['O', 'd', 'L', 'Re', "L'", 'Y_0', 'Y']
    yLabel = ['O', 'd', 'L', 'Re', "L'", 'Y_0', 'Y']
    # Data preparation
    data = np.array([
        [1, 0.76, 0.89, 0.86, 0.01, -0.34, -0.55],
        [0.76, 1, 0.97, 0.97, -0.46, -0.52, -0.33],
        [0.89, 0.97, 1, 0.99, -0.34, -0.54, -0.4],
        [0.86, 0.97, 0.99, 1, -0.38, -0.56, -0.4],
        [0.01, -0.46, -0.34, -0.38, 1, 0.46, 0.06],
        [-0.34, -0.52, -0.54, -0.56, 0.46, 1, -0.04],
        [-0.55, -0.33, -0.4, -0.4, 0.06, -0.04, 1]
    ])
    # Plotting phase
    fig, ax = plt.subplots()
    # Define the tick marks for x and y axes
    ax.set_yticks(range(len(yLabel)))
    ax.set_yticklabels(yLabel, fontdict={'family': 'Calibri', 'weight': 'bold'})
    ax.set_xticks(range(len(xLabel)))
    ax.set_xticklabels(xLabel, fontdict={'family': 'Calibri', 'weight': 'bold'})
    # Create the heatmap with a chosen color scheme
    im = ax.imshow(data, cmap="Reds", vmin=-1, vmax=1)
    # Add a color scale bar on the right
    cbar = plt.colorbar(im)
    cbar.ax.tick_params(labelsize=10)  # Set font size of colorbar ticks
    # Set font for the colorbar ticks
    cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontdict={'family': 'Calibri', 'weight': 'bold'})
    # Annotate each cell with its numeric value
    for i in range(len(yLabel)):
        for j in range(len(xLabel)):
            ax.text(j, i, f'{data[i, j]:.2f}',
                    ha="center", va="center", color="black",
                    fontdict={'family': 'Calibri', 'weight': 'bold'})
    # Add a title
    plt.title("Pearson Coefficient", fontdict={'family': 'Calibri', 'size': 16, 'weight': 'bold'})
    # Show the plot
    fig.tight_layout()
    plt.show()
draw()

# import time
import argparse
import sys
import os
import os.path as osp

import numpy as np
import torch
import pandas as pd

from training.gnn_y import train_gnn_y
from uci.uci_subparser import add_uci_subparser
from utils.utils import auto_select_gpu
from uci.uci_data import load_data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_types', type=str, default='EGSAGE_EGSAGE')
    parser.add_argument('--post_hiddens', type=str, default=None,) # default to be 1 hidden of node_dim
    parser.add_argument('--concat_states', action='store_true', default=False)
    parser.add_argument('--norm_embs', type=str, default=None,) # default to be all true
    parser.add_argument('--aggr', type=str, default='mean',)
    parser.add_argument('--node_dim', type=int, default=16)
    parser.add_argument('--edge_dim', type=int, default=16)
    parser.add_argument('--edge_mode', type=int, default=1)  # 0: use it as weight 1: as input to mlp
    parser.add_argument('--gnn_activation', type=str, default='relu')
    parser.add_argument('--impute_hiddens', type=str, default='')
    parser.add_argument('--impute_activation', type=str, default='relu')
    parser.add_argument('--predict_hiddens', type=str, default='')
    parser.add_argument('--epochs', type=int, default=5000)
    parser.add_argument('--opt', type=str, default='adam')
    parser.add_argument('--opt_scheduler', type=str, default='none')
    parser.add_argument('--opt_restart', type=int, default=0)
    parser.add_argument('--opt_decay_step', type=int, default=1000)
    parser.add_argument('--opt_decay_rate', type=float, default=0.9)
    parser.add_argument('--dropout', type=float, default=0.)
    parser.add_argument('--weight_decay', type=float, default=0.)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--known', type=float, default=0.7) # 1 - edge dropout rate
    parser.add_argument('--valid', type=float, default=0.) # valid-set ratio
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--log_dir', type=str, default='y0')
    parser.add_argument('--domain',type=str,default='uci')
    parser.add_argument('--data',type=str,default='concrete')
    parser.add_argument('--node_mode',type=int,default=1)
    parser.add_argument('--train_edge',type=float,default=0.7)
    parser.add_argument('--split_by',type=str,default='y')
    parser.add_argument('--train_y',type=float,default=0.7)
    subparsers = parser.add_subparsers()
    add_uci_subparser(subparsers)
    args = parser.parse_args()
    print(args)

    # select device
    if torch.cuda.is_available():
        cuda = auto_select_gpu()
        os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        os.environ['CUDA_VISIBLE_DEVICES'] = str(cuda)
        print('Using GPU {}'.format(os.environ['CUDA_VISIBLE_DEVICES']))
        device = torch.device('cuda:{}'.format(cuda))
    else:
        print('Using CPU')
        device = torch.device('cpu')

    seed = args.seed
    np.random.seed(seed)
    torch.manual_seed(seed)
    data = load_data(args)

    log_path = './{}/test/{}/{}/'.format(args.domain,args.data,args.log_dir)
    os.makedirs(log_path)

    cmd_input = 'python ' + ' '.join(sys.argv) + '\n'
    with open(osp.join(log_path, 'cmd_input.txt'), 'a') as f:
        f.write(cmd_input)

    train_gnn_y(data, args, log_path, device)

if __name__ == '__main__':
    main()
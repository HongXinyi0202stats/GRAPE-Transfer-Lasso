import sys
sys.getdefaultencoding()
import pickle
import numpy as np
np.set_printoptions(threshold=1000000000)
path='D:/result.pkl'
file=open(path,'rb')
inf=pickle.load(file,encoding='iso-8859-1')
print(inf)
inf=str(inf)
obj_path='D:/data.txt'
ft=open(obj_path,'w')
ft.write(inf)
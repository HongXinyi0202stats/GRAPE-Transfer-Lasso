# TransLasso
Rcode for the TransLasso algorithm.
The paper, Transfer Learning for High-dimensional Linear Regression, can be found at https://arxiv.org/abs/2006.10593.

The main functions are in "TransLasso-functions.R" .

An example is provided in "TransLasso-examples.R" .

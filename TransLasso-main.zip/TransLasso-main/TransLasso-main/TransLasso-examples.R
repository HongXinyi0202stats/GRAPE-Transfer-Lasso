### An example
#library(MASS)
library(mvtnorm)
### coefficient generating functions used in the simulation
Coef.gen<- function(s, h, q=30, size.A0, M, sig.beta, sig.delta1, sig.delta2, p, exact=T){
  
  # 指定在模拟的系数向量 beta0 中有多少个非零元素 这里表示有s个非零元素
  # 实际上模拟了高维的情况 其中仅会有s个变量会对response产生影响 即仅有这些变量的beta不为0(在high dimension的真实情况下)
  beta0 <- c(rep(sig.beta,s), rep(0, p - s))
  W <- rep.col(beta0,  M)
  # W是系数矩阵
  
  # ten prior estimates
  # 此处对于第一个特征给定一个确定的bias，保证auxiliary data的特征和primary data之间存在异质性
  W[1,]<-W[1,]-2*sig.beta
  
  for(k in 1:M){
    if(k <= size.A0){
      if(exact){
        # sample(1:p, h, replace)表示从1:p中抽取h个
        samp0<- sample(1:p, h, replace=F)
        # 模拟了在samp0索引对应特征的影响力减弱 针对第K个auxiliary set
        W[samp0,k] <-W[samp0,k] + rep(-sig.delta1, h)
      }else{
        # 对系数进行随机的调整 可能增强 可能减弱
        W[1:100,k] <-W[1:100,k] + rnorm(100, 0, h/100)
      }
    }else{
      # 如果不属于size.A0 即那些没有什么价值的auxiliary data
      if(exact){
        # 针对价值并不高的auxiliary data 使用不同的系数调整策略
        samp1 <- sample(1:p, q, replace = F)
        W[samp1,k] <- W[samp1,k] + rep(-sig.delta2,q)
      }else{
        W[1:100,k] <-W[1:100,k] + rnorm(100, 0, q/100)
      }
    }
  }
  
  return(list(W=W, beta0=beta0))
}


source("D:/python_projects/Transfer-Learning/TransLasso-main/TransLasso-main/TransLasso-functions.R")

set.seed(123)
# p表示特征dimension
p = 500
s = 16
M = 20

# 前s个元素的beta被设置为0.3
sig.beta = 0.3
sig.z <- 1
n0 <- 150
# auxiliary集的数量
M = 20
n.vec <- c(n0, rep(100, M))
Sig.X <- diag(1, p)
Niter = 200
l1=T

# size.A0表示的是用于模型优化的辅助数据集的索引
size.A0 = 12 
h=6
A0 = 1:size.A0

coef.all <-Coef.gen(s, h = h, q = 2*s, size.A0 = size.A0,  M = M,  sig.beta = sig.beta,
             sig.delta1 = sig.beta, sig.delta2 = sig.beta+0.2, p = p, exact=F)

B <- cbind(coef.all$beta0, coef.all$W)

beta0 <- coef.all$beta0

### generate the data
X <- NULL
y <- NULL

# primary data就是k=1时生成的第一组数据
# auxiliary data组数为M
for (k in 1:(M + 1)) {
  # 按行拼接 
  # rep(0,p)表示均值向量 都为均值为0
  X <- rbind(X, rmvnorm(n.vec[k], rep(0, p), Sig.X))
  
  # ind.k 表示第k个auxiliary data的索引
  ind.k <- ind.set(n.vec, k)
  if(k == 1){
    primary_data = X[ind.k,]
    write.csv(primary_data, "D:/python_projects/Transfer-Learning/Primary_data.csv", row.names = FALSE)
  }
  else{
    auxiliary_data = X[ind.k,]
    filename = paste("D:/python_projects/Transfer-Learning/Auxiliary_data_", k-1, ".csv", sep="")
    write.csv(auxiliary_data, filename, row.names = FALSE)
  }
  # generate y according to X and B
  y <- c(y, X[ind.k, ] %*% B[, k] + rnorm (n.vec[k], 0, 1))
}

# 保存X和Y
# 输出X到CSV文件 此时X仅有第前p列是primary data
write.csv(X[(n0+1):nrow(X),], "D:/python_projects/Transfer-Learning/All_Auxiliary_data.csv", row.names = FALSE)

# 输出 y 到 CSV 文件
write.csv(y, "D:/python_projects/Transfer-Learning/Y_data.csv", row.names = FALSE)
write.csv(X, "D:/python_projects/Transfer-Learning/X.csv", row.names = FALSE)


# compute init beta
# 使用primary data计算得到回归系数
mse.vec<-rep(NA,6)
beta.init <-
  as.numeric(glmnet(X[1:n.vec[1], ], y[1:n.vec[1]], lambda = sqrt(2 * log(p) / n.vec[1]))$beta)
mse.vec[1] = mse.fun(as.numeric(beta.init), beta0)$est.err

# Oracle Trans-Lasso 
# 如果完全不使用auxiliary data进行impute 那么就是beta.init
# 如果要使用auxiliary 调用beta.kA
if (size.A0 == 0) {
  beta.kA <- beta.init
} else{
  beta.kA <- las.kA(X, y, A0 = 1:size.A0, n.vec = n.vec, l1=l1)$beta.kA
}
mse.vec[2] = mse.fun(as.numeric(beta.kA), beta0)$est.err

# Trans-Lasso 
# 完全是data-driven的 不知道应当使用哪些A0 直接输入X,y
prop.re1 <- Trans.lasso(X, y, n.vec, I.til = 1:50, l1 = l1)
prop.re2 <- Trans.lasso(X, y, n.vec, I.til = 101:n.vec[1], l1=l1)

if(size.A0 > 0 & size.A0< M){ # Rank.re characterizes the performance of the sparsity index Rk
  Rank.re<- (sum(prop.re1$rank.pi[1:size.A0]<=size.A0) +
                     sum(prop.re2$rank.pi[1:size.A0]<=size.A0))/2/size.A0
}else{Rank.re <- 1 }
beta.prop <- (prop.re1$beta.hat + prop.re2$beta.hat) / 2
mse.vec[3] = mse.fun(beta.prop, beta0)$est.err

### A method for comparison: it has the same pipeline of the Trans-Lasso 
### but with sparsity index R_k=\|w^{(k)}-\beta\|_1 and a naive aggregation (empirical risk minimization)
prop.sp.re1 <- Trans.lasso.sp(X, y, n.vec, I.til = 1:50, l1 = l1)
prop.sp.re2 <- Trans.lasso.sp(X, y, n.vec, I.til = 101:n.vec[1], l1=l1)
if(size.A0 > 0 & size.A0< M){
  Rank.re.sp <- (sum(prop.sp.re1$rank.pi[1:size.A0]<=size.A0) +
                        sum(prop.sp.re2$rank.pi[1:size.A0]<=size.A0))/2/size.A0
}else{Rank.re.sp <-1 }
beta.sp <- (prop.sp.re1$beta.sp + prop.sp.re2$beta.sp) / 2
mse.vec[4] = mse.fun(beta.sp, beta0)$est.err    

### another method for comparison: it is the same as Trans-Lasso except 
### that the bias correction step (step 2 of Oracle Trans-Lasso) is omitted
beta.pool<-(prop.re1$beta.pool+prop.re2$beta.pool)/2
mse.vec[5] = mse.fun(beta.pool, beta0)$est.err

## naive translasso: simply assumes A0=1:K 使用所有的auxiliary data去做
beta.all <- las.kA(X, y, A0 = 1:M, n.vec = n.vec, l1=l1)$beta.kA
mse.vec[6] = mse.fun(as.numeric(beta.all), beta0)$est.err

cat(mse.vec, '\n')
cat(Rank.re, Rank.re.sp, '\n')




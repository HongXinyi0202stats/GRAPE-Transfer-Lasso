library(MASS)
library(mvtnorm) #Multivariate Normal and t Distributions

###Part1:生成simulation要用的系数
Coef.gen<-function(s,h,q=30,size.A0,M,sig.beta,sig.delta1,sig.delta2,p,exact=T){
  
  ##1.生成beta0
  beta0<-c(rep(sig.beta,s),rep(0,p-s))
  #beta0 是一个长度为 p 的向量，前 s 个元素为 sig.beta，后面 p-s 个元素为 0。
 
  
  ##2.生成W
  W<-rep.col(beta0,M)
  #W是一个p*m的矩阵，每一列都是beta0
  W[1,]<-W[1,]-2*sig.beta
  
  ##3.逐列调整矩阵W
  for(k in 1:M){
    if(k<=size.A0){
      if(exact){#如果是有价值的auxiliary data
        samp0<-sample(1:p,h,replace=F)
        #从1:p中抽取h个
        W[samp0,k]<-W[samp0,k]+rep(-sig.delta1,h)
                }
      else{
        W[1:100,k]<-W[1:100,k]+rnorm(100,0,h/100)
          }
    }
    else{#如果是没有价值的auxiliary data
      if(exact){
        samp1<-samp(1:p,q,replace=F)
        W[samp1,k]<-W[samp1,k]+rep(-sig.delta2,q)
      }
      else{
        W[1:100,k]<-W[1:100,k]+rnorm(100,0,q/100)
      }
    }
  }
  #如果 k <= size.A0，表示这是“有价值的辅助数据”，并进一步判断 exact 是否为 TRUE：
  #当 exact = TRUE 时，从 1:p 中随机抽取 h 个元素索引，将它们的值减去 sig.delta1。
  #当 exact = FALSE 时，对前 100 个元素添加一个服从正态分布的随机数，均值为 0，标准差为 h/100。
  #如果 k > size.A0，表示这是“没有价值的辅助数据”：
  #当 exact = TRUE 时，从 1:p 中随机抽取 q 个元素索引，将它们的值减去 sig.delta2。
  #当 exact = FALSE 时，对前 100 个元素添加一个服从正态分布的随机数，均值为 0，标准差为 q/100。
  return(list(W=W,beta0=beta0))
  }

###Part2:详细做参数设置
source("D:/Information/科研/GRAPE+Transfer/Transfer-Learning/TransLasso-main/TransLasso-main/TransLasso-functions.R")
set.seed(825)
p=500 ##500 dimension
s=16##前16个元素被设置成0.3
M=20 ##auxiliary集总体数量
sig.beta=0.3 # 前16个元素设置成sig.beta
sig.z<-1# 其他噪声的标准差
n0<-150# 基础数据集的样本量
n.vec<-c(n0,rep(100,M)) # 样本量向量，第一个为主数据，后面是每个辅助集
Sig.X<-diag(1,p)# 特征协方差矩阵（单位矩阵）
Niter=200# 迭代次数
l1=TRUE# 是否使用L1范数，默认为TRUE
size.A0=12# 有用的辅助数据的数量
h=6# 抽取的特征个数
A0=1:size.A0# 用于选择有价值数据的索引
coef.all<-Coef.gen(s,h=h,q=2*s,size.A0=size.A0,M=M,sig.beta=sig.beta,sig.delta1=sig.beta,sig.delta2=sig.beta+0.2,p=p,exact=F)
B<-cbind(coef.all$beta0,coef.all$W)
beta0<-coef.all$beta0

###Part3.生成数据，做Simulation
X<-NULL
y<-NULL
for(k in 1:(M+1)){
  X<-rbind(X,rmvnorm(n.vec[k],rep(0,p),Sig.X))
  ind.k<-ind.set(n.vec,k)
  if(k==1){
    primary_data=X[ind.k,]
    write.csv("D:/Information/科研/GRAPE+Transfer/Transfer-Learning/TransLasso-main/data/Primary_data.csv",row.names=FALSE)
  }
  else{
    auxiliary_data=X[ind.k,]
    filename=paste("D:/Information/科研/GRAPE+Transfer/Transfer-Learning/TransLasso-main/data/Auxiliary_data_",k-1,".csv",sep="")
    write.csv(auxiliary_data,filename,row.names=FALSE)
  }
  ##根据Y=XB+EPSILON
  y<-c(y,X[ind.k,]%*%B[,k]+rnorm(n.vec[k],0,1))
}
##集体将X与Y保存
write.csv(X[n0+1:nrow(X)],"D:/Information/科研/GRAPE+Transfer/Transfer-Learning/TransLasso-main/data/All_Auxiliary_data.csv",row.names=FALSE)
write.csv(y,"D:/Information/科研/GRAPE+Transfer/Transfer-Learning/TransLasso-main/data/Y_data.csv",row.names=FALSE)

###Part4.计算回归系数

   ##Method1 仅使用主数据集进行Lasso回归
   mse.vec<-rep(NA,6)
   beta.init <-as.numeric(glmnet(X[1:n.vec[1], ], y[1:n.vec[1]], lambda = sqrt(2 * log(p) / n.vec[1]))$beta)
   mse.vec[1] = mse.fun(as.numeric(beta.init), beta0)$est.err #填在mse向量的第1个位置，后面以此类推
   
   ##Method2 Oracle Trans-Lasso 假设已知哪些辅助数据集是有用的,使用las.kA函数对主数据集和有用的辅助数据集进行联合建模
   if (size.A0 == 0) {
     beta.kA <- beta.init    # 如果完全不使用auxiliary data进行impute 那么就是beta.init
   } else{
     beta.kA <- las.kA(X, y, A0 = 1:size.A0, n.vec = n.vec, l1=l1)$beta.kA   # 如果要使用auxiliary 调用beta.kA
   }
   mse.vec[2] = mse.fun(as.numeric(beta.kA), beta0)$est.err
   
   ##Method3  Trans-Lasso data-driven 自动选择有用的辅助数据集
   prop.re1 <- Trans.lasso(X, y, n.vec, I.til = 1:50, l1 = l1)
   prop.re2 <- Trans.lasso(X, y, n.vec, I.til = 101:n.vec[1], l1=l1)
   if(size.A0 > 0 & size.A0< M){ 
     Rank.re<- (sum(prop.re1$rank.pi[1:size.A0]<=size.A0) +sum(prop.re2$rank.pi[1:size.A0]<=size.A0))/2/size.A0
     }else{Rank.re <-1}
   beta.prop <- (prop.re1$beta.hat + prop.re2$beta.hat)/2
   mse.vec[3] = mse.fun(beta.prop, beta0)$est.err
   
   ##Method4 选择信息集进行Q集合
   prop.sp.re1 <- Trans.lasso.sp(X, y, n.vec, I.til = 1:50, l1 = l1)
   prop.sp.re2 <- Trans.lasso.sp(X, y, n.vec, I.til = 101:n.vec[1], l1=l1)
   if(size.A0 > 0 & size.A0< M){
     Rank.re.sp <- (sum(prop.sp.re1$rank.pi[1:size.A0]<=size.A0) +
                      sum(prop.sp.re2$rank.pi[1:size.A0]<=size.A0))/2/size.A0
   }else{Rank.re.sp <-1 }
   beta.sp <- (prop.sp.re1$beta.sp + prop.sp.re2$beta.sp) / 2
   mse.vec[4] = mse.fun(beta.sp, beta0)$est.err  
   
   ##Method5 选择信息集并进行Lasso回归,类似于Trans-Lasso,通过比较个辅助数据集的估计系数与主数据集估计系数之间的差异，选择有用的辅助数据集
   beta.pool<-(prop.re1$beta.pool+prop.re2$beta.pool)/2
   mse.vec[5] = mse.fun(beta.pool, beta0)$est.err
   
   ##Method6 Naive 合并所有数据集并进行Lasso回归
   beta.all <- las.kA(X, y, A0 = 1:M, n.vec = n.vec, l1=l1)$beta.kA
   mse.vec[6] = mse.fun(as.numeric(beta.all), beta0)$est.err
   
   cat(mse.vec, '\n')
   cat(Rank.re, Rank.re.sp, '\n')












